import React, { useState } from 'react';

function SoundRecordingForm() {
    const [formData, setFormData] = useState({
        doctorName: '',
        patientName: '',
        patientAge: '',
        recordingDate: '',
        soundFile: null
    });

    const handleInputChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleFileChange = (e) => {
        setFormData({
            ...formData,
            soundFile: e.target.files[0]
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        // Create FormData object
        const formDataObj = new FormData();
        formDataObj.append('doctorName', formData.doctorName);
        formDataObj.append('patientName', formData.patientName);
        formDataObj.append('patientAge', formData.patientAge);
        formDataObj.append('recordingDate', formData.recordingDate);
        formDataObj.append('soundFile', formData.soundFile);
        console.log(formDataObj)
        try {
            const response = await fetch('/form/submit', {
                method: 'POST',
                body: formDataObj // Pass FormData object
            });
            if (response.ok) {
                // If the response is successful, reset the form
                setFormData({
                    doctorName: '',
                    patientName: '',
                    patientAge: '',
                    recordingDate: '',
                    soundFile: null
                });
                alert('Recording stored successfully');
            } else {
                // Handle error response
                const errorMessage = await response.text();
                throw new Error(errorMessage);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Failed to store recording');
        }
    };
    

    return (
        <form onSubmit={handleSubmit}>
            <label>Doctor's Name:</label>
            <input type="text" name="doctorName" value={formData.doctorName} onChange={handleInputChange} />
            <label>Patient's Name:</label>
            <input type="text" name="patientName" value={formData.patientName} onChange={handleInputChange} />
            <label>Patient's Age:</label>
            <input type="number" name="patientAge" value={formData.patientAge} onChange={handleInputChange} />
            <label>Date of Recording:</label>
            <input type="date" name="recordingDate" value={formData.recordingDate} onChange={handleInputChange} />
            <label>Upload Sound File:</label>
            <input type="file" name="soundFile" onChange={handleFileChange} />
            <button type="submit">Submit</button>
        </form>
    );
}

export default SoundRecordingForm;
